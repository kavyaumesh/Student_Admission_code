// Author : Kavya Umesh Naik
// Codes : Student_admission


#ifndef APPCONST_H_INCLUDED
#define APP_CONST_H_INCLUDED

#define STUDENT_NAME_LEN 64
#define PROGRAM_NAME_LEN 22
#define EMAIL_LEN     20
#define ADMISSION_STATUS 20

#endif  // APPCONST_H_INCLUDED

